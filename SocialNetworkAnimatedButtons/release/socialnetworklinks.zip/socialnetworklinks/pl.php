<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_f066c778ec00db9d558d62e4f87576ed'] = 'Linki do portali społecznościowych';
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_2c80979379b0cecc4e8a0e7a9b7f4d43'] = 'Moduł tworzy animowanie linki do portali społecznościowych';
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_c7b1980cfc8357e6da4787897773a105'] = 'Top';
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_f9e4884c7654daa6581b42ed90aeaba4'] = 'lewa kolumna';
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_feb6cc332459769fe15570bf332a6b50'] = 'prawa kolumna';
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_ded40f2a77c30efc6062db0cbd857746'] = 'Stopka';
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Pozycja';
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_43781db5c40ecc39fd718685594f0956'] = 'zapisz';
$_MODULE['<{socialnetworklinks}prestashop>socialnetworklinks_23222d3cb0d5f3c3bad3600cc57be0ae'] = 'z dumą rozwijane przez';
$_MODULE['<{socialnetworklinks}prestashop>column_b0479b7a89697287cc08ba9c21c85eac'] = 'Darmowe moduły prestashop';
