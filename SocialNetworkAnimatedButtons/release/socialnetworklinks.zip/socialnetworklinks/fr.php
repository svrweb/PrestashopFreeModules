<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{socialnetworklinks}prestashop>column_b0479b7a89697287cc08ba9c21c85eac'] = 'Modules prestashop gratuit';
