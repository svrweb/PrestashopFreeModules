<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{checkout}prestashop>checkout_80a760e7b019cdf8f9a6517c12c9308f'] = 'Pay with credit card. The validation process is in real time.';
