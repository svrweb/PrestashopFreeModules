<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3a3f8a7ff90a73aec5ebd661bc92b048'] = 'Facebook commenti';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_6ae34f196a8c618f2f9778ea75a41f3d'] = 'Aggiungi blocco di commenti a ogni pagina del prodotto nel vostro negozio.';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_7278125be8c9aceaaf5d3f7645b45c5c'] = 'Impostazioni salvate';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_f4f70727dc34561dfde1a3c529b6205c'] = 'impostazioni';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_75fa820aebc10bf31b310065b38447c7'] = 'Product Tabs';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9787028383eef1dfde2f09093a851373'] = 'Product Footer';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9235843ddcf97caf4b7c712dbc95d045'] = 'Commenti casella di larghezza';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_0f2898ac15073825a5c5d88723264685'] = 'Numero di commenti';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_2ac43aa43bf473f9a9c09b4b608619d3'] = 'colore della luce';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_a82fd95db10ff25dfad39f07372ebe37'] = 'colore scuro';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_4994a8ffeba4ac3140beb89e8d41f174'] = 'lingua';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3124e63231a4594958d87771b4aaf064'] = 'Amministratore';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3d21e9d303e562c108fdb16f576a8ad6'] = 'Separare tutti gli ID amministratore da virgole';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_498723c00388358f83d6586606edd577'] = 'APP id';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_aee345f5ca3a8198dc27a4475cb2c824'] = 'È possibile usare la propria app facebook';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9daf1fb753b42c3cdc8f1d01669cd6d8'] = 'Salva impostazioni';
$_MODULE['<{facebookcomments}prestashop>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Commenti';
